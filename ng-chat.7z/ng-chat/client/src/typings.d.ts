/* SystemJS module definition */
declare var module: {
  id: string;
};
